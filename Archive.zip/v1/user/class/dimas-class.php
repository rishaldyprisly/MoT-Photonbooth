<?php
    class users{

        private $conn;
        private $db_table = "Users";

        public $ID;
        public $NIKR;
        public $Password;
        public $Fullname;
        public $Unit;
        public $Bod;
        public $Phone;
        public $Email;
        public $Address;
        public $Role;
        public $Photo;
                   
                    
        public function __construct($db){
            $this->conn = $db;
        }

        public function login(){
            $sqlQuery = "SELECT * FROM Users  WHERE NIKR = '".$this->NIKR."'  AND Password = SHA1('".$this->Password."')  LIMIT 1";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->ID= $dataRow['ID'];
            $this->NIKR=$dataRow['NIKR'];
            $this->Password=$dataRow['Password'];
            $this->Fullname=$dataRow['Fullname'];
            $this->Unit=$dataRow['Unit'];
            $this->BoD=$dataRow['BoD'];
            $this->Phone=$dataRow['Phone'];
            $this->Email=$dataRow['Email'];
            $this->Address=$dataRow['Address'];
            $this->Role=$dataRow['Role'];
            $this->Photo=$dataRow['Photo'];

        }
    }

    class med{
        private $conm;
        private $db_table = "Medical";
        public $ID;
        public $NIK;
        public $Fullname;
        public $Age;
        public $Unit;
        public $Role;
        public $HealthIssue;
        public $Diagnostic;
        public $Treatment;
        public $Pills;
        public $Recomendation;
        public $ReportDate;
        public $DiagnoseDate;
        public function __construct($dbm){
            $this->conm = $dbm;
        }
        
       
        
        public function getSpecific(){
            $sqlQuery = "SELECT * FROM Medical  WHERE NIK LIKE  '".$this->NIK."%' ORDER BY ID ASC";
            $stmt = $this->conm->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
        
         public function getHome(){
            $sqlQueries = "SELECT (SELECT COUNT(*) FROM Medical WHERE NOT Diagnostic = 'Waiting' AND NIK = '".$this->NIK."' ) as Diagnosed, (SELECT COUNT(*)  FROM Medical WHERE Diagnostic = 'Waiting' AND NIK = '".$this->NIK."') AS Rep";
            $stmt = $this->conm->prepare($sqlQueries);
            $stmt->execute();
            $dataHome = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->Diagnosed= $dataHome['Diagnosed'];
            $this->Rep=$dataHome['Rep'];
        }


        public function create_medical(){
            $sqlQuery = "INSERT INTO Medical SET
                        NIK          = :NIK,
                        Fullname     = :Fullname,
                        Age          = :Age,
                        Unit         = :Unit,
                        Role         = :Role,
                        HealthIssue  = :HealthIssue,
                        Description  = :Description,
                        Diagnostic   = :Diagnostic,
                        Treatment    = :Treatment,
                        Pills        = :Pills,
                        Recomendation = :Recomendation,
                        ReportDate    = :ReportDate,
                        DiagnoseDate  = :DiagnoseDate";

            $stmt = $this->conm->prepare($sqlQuery);
            $this->NIK      = htmlspecialchars(strip_tags($this->NIK));
            $this->Fullname = htmlspecialchars(strip_tags($this->Fullname));
            $this->Age      = htmlspecialchars(strip_tags($this->Age));
            $this->Unit     = htmlspecialchars(strip_tags($this->Unit));
            $this->Role     = htmlspecialchars(strip_tags($this->Role));
            $this->HealthIssue= htmlspecialchars(strip_tags($this->HealthIssue));
            $this->Description= htmlspecialchars(strip_tags($this->Description));
            
            $this->Diagnostic= htmlspecialchars(strip_tags("Waiting"));
            $this->Treatment= htmlspecialchars(strip_tags("Waiting"));
            $this->Pills= htmlspecialchars(strip_tags("Waiting"));
            $this->Recomendation= htmlspecialchars(strip_tags("Waiting"));
            
            $this->ReportDate = htmlspecialchars(strip_tags($this->ReportDate));
            $this->DiagnoseDate= htmlspecialchars(strip_tags("Waiting"));

            $stmt->bindParam(":NIK",      $this->NIK);
            $stmt->bindParam(":Fullname", $this->Fullname); 
            $stmt->bindParam(":Age",      $this->Age);
            $stmt->bindParam(":Unit",     $this->Unit);
            $stmt->bindParam(":Role",      $this->Role);
            $stmt->bindParam(":HealthIssue", $this->HealthIssue); 
            $stmt->bindParam(":Description", $this->Description); 
            
            $stmt->bindParam(":Diagnostic", $this->Diagnostic); 
            $stmt->bindParam(":Treatment", $this->Treatment); 
            $stmt->bindParam(":Pills", $this->Pills); 
            $stmt->bindParam(":Recomendation", $this->Recomendation); 
            $stmt->bindParam(":ReportDate", $this->ReportDate); 
            $stmt->bindParam(":DiagnoseDate",      $this->DiagnoseDate);
            

            if($stmt->execute()){
               return true;
            }
            else{
                return false;
            }
        

        }
    }
?>

