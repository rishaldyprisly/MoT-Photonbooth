<?php
    ini_set('display_errors', 1);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../class/dimas-class.php';

    $AUTH_USER = 'dimas';
    $AUTH_PASS = '12312askdjaLSIDSAIOoase21329Yo0239lsdmlphjijwe';

	        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	        $is_not_authenticated = (!$has_supplied_credentials || $_SERVER['PHP_AUTH_USER'] != $AUTH_USER || $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS);
	        $authenticated = ( $has_supplied_credentials && $_SERVER['PHP_AUTH_USER'] = $AUTH_USER && $_SERVER['PHP_AUTH_PW'] = $AUTH_PASS );

        	if ($is_not_authenticated) {

		        echo '{"Status":"ERROR 401 - Invalid Credential."}';
		        exit;
	            }
 	        if($authenticated){

                $database = new Database();
                $db = $database->getConnection();
                $item = new users($db);
                $item->NIKR = isset($_GET['NIKR']) ? $_GET['NIKR']: die();
                $item->Password = isset($_GET['Password']) ? $_GET['Password']: die();
                $item->login();

                if($item-> ID!= NULL){ 
                    $user = array(
                    "ID"        => $item->ID,
                    "NIKR"      => $item->NIKR,
                    "Password"  => $item->Password,
                    "Fullname"  => $item->Fullname,
                    "Unit"      => $item->Unit,
                    "BoD"       => $item->BoD,
                    "Phone"     => $item->Phone,
                    "Email"     => $item->Email,
                    "Address"   => $item->Address,
                    "Role"      => $item->Role,
                    "Photo"     => $item->Photo

                    );
                http_response_code(200);
                echo json_encode($user);
                }
            else{
                http_response_code(404);
                $response = array("Status"=>"Login Failed Please Check Your Credentials");
                echo json_encode($response);
                }
	        }
?>
