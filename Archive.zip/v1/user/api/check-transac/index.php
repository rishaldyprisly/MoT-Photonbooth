<?php
    ini_set('display_errors', 1);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../class/yobakery.php';

    $AUTH_USER = 'yobakery';
    $AUTH_PASS = '12312askdjaLSIDSAIOoase21329Yo0239lsdmlphjijwe';

	        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	        $is_not_authenticated = (!$has_supplied_credentials || $_SERVER['PHP_AUTH_USER'] != $AUTH_USER || $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS);
	        $authenticated = ( $has_supplied_credentials && $_SERVER['PHP_AUTH_USER'] = $AUTH_USER && $_SERVER['PHP_AUTH_PW'] = $AUTH_PASS );

        	if ($is_not_authenticated) {

		        echo '{"Status":"ERROR 401 - Invalid Credential."}';
		        exit;
	            }
 	        if($authenticated){

               $database = new Database();
                $db = $database->getConnection();
                $item = new transac($db);

                $item->getTransac();

                if($item-> Sequence!= NULL){ 
                    $user = array( "Sequence"=> $item->Sequence );
                http_response_code(200);
                echo json_encode($user);
                }
            else{
                http_response_code(404);
                $response = array("Status"=>"Login Failed Please Check Your Credentials");
                echo json_encode($response);
                }
	        }
?>
