<?php
    ini_set('display_errors', 1);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../class/dimas-class.php';

    $AUTH_USER = 'dimas';
    $AUTH_PASS = '12312askdjaLSIDSAIOoase21329Yo0239lsdmlphjijwe';

	        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	        $is_not_authenticated = (!$has_supplied_credentials || $_SERVER['PHP_AUTH_USER'] != $AUTH_USER || $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS);
	        $authenticated = ( $has_supplied_credentials && $_SERVER['PHP_AUTH_USER'] = $AUTH_USER && $_SERVER['PHP_AUTH_PW'] = $AUTH_PASS );

        	if ($is_not_authenticated) {

		        echo '{"Status":"ERROR 401 - Invalid Credential."}';
		        exit;
	            }
 	        if($authenticated){
                $database = new Database();
                $db = $database->getConnection();
                $items = new med($db);
                $items->NIK = isset($_GET['NIK']) ? $_GET['NIK'] : die();
                
                $stmt = $items->getSpecific();
                $itemCount = $stmt->rowCount();

                if($itemCount > 0){
                $medicalHistory = array();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $e = array(
                    "ID"          => $ID,
                    "NIK"         => $NIK,
                    "Fullname"    => $Fullname,
                    "Age"         => $Age,
                    "Unit"        => $Unit,
                    "Role"        => $Role,
                    "HealthIssue" => $HealthIssue,
                    "Description" => $Description,
                    "Diagnostic"  => $Diagnostic,
                    "Treatment"   => $Treatment,
                    "Pills"       => $Pills,
                    "Recomendation"   => $Recomendation,
                    "Acknowledgement" => $Acknowledgement,
                    "ReportDate"      => $ReportDate,
                    "DiagnoseDate"    => $DiagnoseDate
                    

                
                  
                    );
                array_push($medicalHistory, $e);
                }
                echo json_encode($medicalHistory);
                }

            else{
                http_response_code(404);
                echo json_encode(
                array("message" => "No record found."));
                }
               
	        }
?>
