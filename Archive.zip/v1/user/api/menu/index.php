<?php
    ini_set('display_errors', 1);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    include_once '../../config/database.php';
    include_once '../../class/yobakery.php';
    $AUTH_USER = 'yo-bakery';
    $AUTH_PASS = 'Bq2ie3oqwikeoqwkeokAskjerkjw9eke3348942048294ryw;msd-9sd';
	        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	        $is_not_authenticated = (!$has_supplied_credentials || $_SERVER['PHP_AUTH_USER'] != $AUTH_USER || $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS);
	        $authenticated = ( $has_supplied_credentials && $_SERVER['PHP_AUTH_USER'] = $AUTH_USER && $_SERVER['PHP_AUTH_PW'] = $AUTH_PASS );
        	if ($is_not_authenticated) {
		        echo '{"Status":"ERROR 401 - Invalid Credential."}';
		        exit;
	            }
	        if($authenticated){
                $database = new Database();
                $db = $database->getConnection();

                $items = new menu($db);
                $stmt = $items->getMenu();
                $itemCount = $stmt->rowCount();

                if($itemCount > 0){
                    $device = array();
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                    extract($row);
                    $e = array(
                        "ID" => $ID,
                        "Identifier" => $Identifier,
                        "Name" => $Name,
                        "Category" => $Category,
                        "Price" => $Price
                        );
                        array_push($device, $e);
                        }
                       echo json_encode($device);
                      }
    
                   else{
                    http_response_code(404);
                    echo json_encode(array("message" => "No record found."));
                    }
	     }
?>
