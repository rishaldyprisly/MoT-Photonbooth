<?php
	ini_set('display_errors', 1); 
    ini_set('display_startup_errors', 1); 
    error_reporting(E_ALL);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header('Cache-Control: no-cache, must-revalidate, max-age=0');
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../class/dimas-class.php';
    
     $AUTH_USER = 'dimas';
     $AUTH_PASS = '12312askdjaLSIDSAIOoase21329Yo0239lsdmlphjijwe';
        
	        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	        $is_not_authenticated = (!$has_supplied_credentials || $_SERVER['PHP_AUTH_USER'] != $AUTH_USER || $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS);
	        $authenticated = ( $has_supplied_credentials && $_SERVER['PHP_AUTH_USER'] = $AUTH_USER && $_SERVER['PHP_AUTH_PW'] = $AUTH_PASS );
	        
        	if ($is_not_authenticated) {
		        echo '{"Status":"ERROR 401 - Invalid Credential."}';
		        exit;
	            }
	            
	        if($authenticated){
	             
                $database = new Database();
                $db = $database->getConnection();
                $item = new med($db);
                


                $data = json_decode(file_get_contents("php://input"));  
                $item->NIK          = $data->NIK;
                $item->Fullname     = $data->Fullname;
                $item->Age          = $data->Age;
                $item->Unit         = $data->Unit;
                $item->Role         = $data->Role;
                $item->HealthIssue  = $data->HealthIssue;
                $item->Description  = $data->Description;
                $item->ReportDate   = $data->ReportDate;
                
    
                if($item->create_medical()){
		              http_response_code(200);
                    echo '{"Status":"200 - Medical Data Recorded"}';
                    
                } 
                else{
                    http_response_code(404);
                    
                    echo '{"Status":"201 - Fail To Record Medical Data"}';
                    
                    
                    }  
	            }
	       

  
?>
