<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>MoT Photobooth</title>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
<link href="dist/css/style.css" rel="stylesheet"> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- <script defer src="script.js"></script> -->
<style>
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 33%;
  padding: 30px;
  /*height: 300px;  Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>

</head>

<body style="background-color: #bbbbbb;">

<div class="content">
	<div class="row">
	  <div class="column">
			<div class="holder" align="center">
				<canvas id="myCanvas" width="630" height="810" style="background-color:#fff; display: block;"></canvas>
			</div>
			
		</div>
		<div class="column" >
			<div class="holder">
				<canvas id="myCanvas2" width="480" height="810" style="background-color:transparent; display: block;"></canvas>
			</div>
			
		</div>

		<div class="column" >
			<div class="holder">
				<canvas id="myCanvas3" width="480" height="810" style="background-color:#ffffff; display: block;"></canvas>
			</div>
		
		</div>
	</div>


	<div class="row">
	  <div class="column">
			<div class="holder" align="center">
				<canvas id="myCanvas4" width="500" height="810" style="background-color:transparent; display: block;"></canvas>
			</div>
		
		</div>
		<div class="column" >
			<div class="holder">
				<canvas id="myCanvas5" width="480" height="810"  style="background-color:transparent; display: block;"></canvas>
			</div>
		
		</div>

		<div class="column" >
			<div class="holder">
				<canvas id="myCanvas6" width="480" height="810" style="background-color:transparent; display: block;"></canvas>
				
			</div>
		
		</div>
	</div>
</div>
</body>
<?php 
    $query = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 0, 1");
    while ($row = mysqli_fetch_assoc($query)) {
        $var = $row['Images'];
    }
    $query2 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 1, 1");
    while ($row2 = mysqli_fetch_assoc($query2)) {
        $var2 = $row2['Images'];
    }
    
    $query3 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 2, 1");
    while ($row3 = mysqli_fetch_assoc($query3)) {
        $var3 = $row3['Images'];
    }
    
    $query4 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 3, 1");
    while ($row4 = mysqli_fetch_assoc($query4)) {
        $var4 = $row4['Images'];
    }
    
    $query5 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 4, 1");
    while ($row5 = mysqli_fetch_assoc($query5)) {
        $var5 = $row5['Images'];
    }
    $query6 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 5, 1");
    while ($row6 = mysqli_fetch_assoc($query6)) {
        $var6 = $row6['Images'];
    }
    $query7 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 6, 1");
    while ($row7 = mysqli_fetch_assoc($query7)) {
        $var7 = $row7['Images'];
    }
    $query8 = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 7, 1");
    while ($row8 = mysqli_fetch_assoc($query8)) {
        $var8 = $row8['Images'];
    }
?>

<script type="text/javascript">
	var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext('2d');

	var img = new Image();
	img.src= '<?php echo $var ;?>';
	ctx.drawImage(img, 10, 10,300,240);

	var img2 = new Image();
	img2.src = '<?php echo $var2 ;?>';
	ctx.drawImage(img2, 320, 10, 300, 240);

	var img3 = new Image();
	img3.src= '<?php echo $var3 ;?>';
	ctx.drawImage(img3, 10, 265, 300, 240);

	var img4 = new Image();
	img4.src= '<?php echo $var4 ;?>';
	ctx.drawImage(img4, 320, 265,300,240);

	var img5 = new Image();
	img5.src= '<?php echo $var5 ;?>';
	ctx.drawImage(img5, 10, 530,300,240);

	var img6 = new Image();
	img6.src= '<?php echo $var6 ;?>';
	ctx.drawImage(img6, 320, 530,300,240);
	
	var dataURL = canvas.toDataURL();
	 
    canvas.addEventListener('click', function() { saveLayout() }, false);

	var canvas2 = document.getElementById("myCanvas2");
    var ctx = canvas2.getContext('2d');

	var img = new Image();
	img.src= '<?php echo $var ;?>';
	ctx.drawImage(img, 5, 5,240,240);

	var img2 = new Image();
	img2.src = '<?php echo $var2 ;?>';

	//ctx.setTransform(1, Math.tan(Math.PI/-9), 0, 1, 0, 90);
	ctx.drawImage(img2, 280, 30, 180, 180);

	var img3 = new Image();
	img3.src= '<?php echo $var3 ;?>';
	ctx.drawImage(img3, 12, 265,200,200);

	var img4 = new Image();
	img4.src= '<?php echo $var4 ;?>';;
	ctx.drawImage(img4, 230, 265,220,220);

	var img5 = new Image();
	img5.src= '<?php echo $var5 ;?>';
	ctx.drawImage(img5, 280, 500,180,180);

	var img6 = new Image();
	img6.src= '<?php echo $var6 ;?>';;
	ctx.drawImage(img6, 5, 500,260,255);

	var img7 = new Image();
	img7.src= '<?php echo $var7 ;?>';
	ctx.drawImage(img7, 270, 700,100,100);

	var img8 = new Image();
	img8.src= '<?php echo $var ;?>';
	ctx.drawImage(img8, 375, 700,100,100);
    canvas2.addEventListener('click', function() { saveLayout() }, false);


	var canvas3 = document.getElementById("myCanvas3");
    var ctx = canvas3.getContext('2d');
    
	var img2 = new Image();
	img2.src = '<?php echo $var ;?>';

	ctx.drawImage(img2, 100, 10, 300, 300);

	var img3 = new Image();
	img3.src= '<?php echo $var2 ;?>';
	ctx.drawImage(img3, 20, 320,200,200);

	var img3 = new Image();
	img3.src= '<?php echo $var3 ;?>';
	ctx.drawImage(img3, 240, 320,200,200);


	var img6 = new Image();
	img6.src = '<?php echo $var4 ;?>';
	ctx.drawImage(img6, 5, 535,260,255);

	var img7 = new Image();
	img7.src = '<?php echo $var5 ;?>';
	ctx.drawImage(img7, 270, 570,100,100);

	var img8 = new Image();
	img8.src = '<?php echo $var6 ;?>';
	ctx.drawImage(img8, 375, 570,100,100);

	var img9 = new Image();
	img9.src= '<?php echo $var7 ;?>';
	ctx.drawImage(img9, 270, 690,100,100);

	var img10 = new Image();
	img10.src= '<?php echo $var8 ;?>';
	ctx.drawImage(img10, 375, 690,100,100);
    canvas3.addEventListener('click', function() { saveLayout() }, false);


	var canvas4 = document.getElementById("myCanvas4");
    var ctx = canvas4.getContext('2d');

    var img = new Image();
	img.src= '<?php echo $var ;?>';
	ctx.drawImage(img, 5, 75,240,240);

	var img2 = new Image();
	img2.src = '<?php echo $var2 ;?>';
	ctx.drawImage(img2, 250, 75, 240, 240);

	var img3 = new Image();
	img3.src= '<?php echo $var3 ;?>';
	ctx.drawImage(img3, 15, 350,100,100);
	
	var img3 = new Image();
	img3.src= '<?php echo $var4 ;?>';
	ctx.drawImage(img3, 135, 350,100,100);
	
	var img3 = new Image();
	img3.src= '<?php echo $var5 ;?>';
	ctx.drawImage(img3, 250, 350,100,100);
	
	var img3 = new Image();
	img3.src= '<?php echo $var6 ;?>';
	ctx.drawImage(img3, 370, 350,100,100);
	
	var img8 = new Image();
	img8.src= '<?php echo $var7 ;?>';
	ctx.drawImage(img8, 5, 480,240,240);
	
	var img8 = new Image();
	img8.src= '<?php echo $var8 ;?>';
	ctx.drawImage(img8, 250, 480,240,240);
	canvas4.addEventListener('click', function() { saveLayout() }, false);
	
	
	var canvas5 = document.getElementById("myCanvas5");
    var ctx = canvas5.getContext('2d');

	var img = new Image();
	img.src= '<?php echo $var ;?>';
	ctx.drawImage(img, 125, 10,260,260);

	var img2 = new Image();
	img2.src = '<?php echo $var2 ;?>';
	ctx.drawImage(img2, 125, 275, 260, 260);

	var img3 = new Image();
	img3.src= '<?php echo $var3 ;?>';
	ctx.drawImage(img3, 125, 540,260,260);
	canvas5.addEventListener('click', function() { saveLayout() }, false);
	
	var canvas6 = document.getElementById("myCanvas6");
    var ctx = canvas6.getContext('2d');

	var img = new Image();
	img.src= '<?php echo $var ;?>';
	ctx.drawImage(img, 25, 10,200,200);

	var img2 = new Image();
	img2.src = '<?php echo $var2 ;?>';
	ctx.drawImage(img2, 25, 215, 200, 200);

	var img3 = new Image();
	img3.src= '<?php echo $var3 ;?>';
	ctx.drawImage(img3, 25, 420,200,200);
	
	var img4 = new Image();
	img4.src= '<?php echo $var4 ;?>';
	ctx.drawImage(img4, 25, 625,200,200);
	
	var img = new Image();
	img.src= '<?php echo $var5 ;?>';
	ctx.drawImage(img, 255, 10,200,200);

	var img2 = new Image();
	img2.src = '<?php echo $var6 ;?>';
	ctx.drawImage(img2, 255, 215, 200, 200);

	var img3 = new Image();
	img3.src= '<?php echo $var7 ;?>';
	ctx.drawImage(img3, 255, 420,200,200);
	
	var img4 = new Image();
	img4.src= '<?php echo $var8 ;?>';
	ctx.drawImage(img4, 255, 625,200,200);


    canvas6.addEventListener('click', function() { saveLayout() }, false);

    function saveLayout() {
                var dataURL = canvas.toDataURL("image/jpg");
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "save-layout.php");
                xhr.onload = function() {
                    if (xhr.readyState == 4 ) {
                        if(xhr.status == 200) {
                            console.log("XHR COMPLETED");
                            window.location = 'https://localhost/photobooth/clients/pik/filter.php';                            
                        }
                    }
                };
                var form = new FormData();
                form.append("image", dataURL);
                xhr.send(form);
                
                // window.location = 'https://mot.rsxms.com/clients/pik/filter.php'
            }

</script>
</html>
