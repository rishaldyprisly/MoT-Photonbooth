<?php 
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');

if ( isset($_POST["image"]) && !empty($_POST["image"]) && isset($_POST["layout"])  ) { 
	$data     = $_POST["image"];
	$frame    = $_POST["layout"];
	$filter   = $_POST["filter"];
	$uri      =  substr($data,strpos($data,","));
	$folder   = "layout";
	$file     =  $phone ."-". md5(uniqid()) . ".jpg";
	$location = $folder . "/" . $file;
	
	
	file_put_contents($folder . "/" . $file, base64_decode($uri));
	$query = mysqli_query($management_connection, "INSERT INTO Layout (Booth, Phone, Frame, Filter, Images) VALUES ('PIK - Cove', '$phone', '$frame', '$filter', '$location' )");
	
	echo $file;
}
?>