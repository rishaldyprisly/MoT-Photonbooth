<?php
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');
$query = mysqli_query($management_connection, "SELECT * FROM Layout WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 1");
while ($row = mysqli_fetch_assoc($query)) {
    $imgs   = $row['Images'];
    $frame  = $row['Frame'];
    $filter = $row['Filter'];
    
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>MoT Photobooth</title>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
<link href="dist/css/style.css" rel="stylesheet"> 
<link rel="stylesheet" href="dist/css/instagram.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- <script defer src="script.js"></script> -->
<style>
.centered {
          position: absolute;
          top: 50%;
          left: 55%;
          transform: translate(-50%, -50%);
        }
</style>

</head>

<body style="background-color: #ffffff;" onload="doPrint()" >
<!--  -->
<div class="content" >
	<div class="row " >
		<div class="holder " style="background: #ffffff;" >
      <?php  
        if ($filter == 1){
          echo '<img src=" '. $imgs .'" class="centered filter-gingham"  >';
        }

        if ($filter == 2){
          echo '<img src=" '. $imgs .'" class="centered filter-inkwell"  >';
        }
        if ($filter == 3){
          echo '<img src=" '. $imgs .'" class="centered filter-valencia"  >';
        }
        if ($filter == 4){
          echo '<img src=" '. $imgs .'" class="centered filter-perpetua"  >';
        }

        if ($frame == 1){
          echo '<img src="dist/images/frames-1.png" class="centered" width="300" >';
        }

        if ($frame == 2){
          echo '<img src="dist/images/frames-2.png" class="centered"  >';
        }
        if ($frame == 3){
          echo '<img src="dist/images/frames-3.png" class="centered"  >';
        }
        if ($frame == 4){
          echo '<img src="dist/images/frames-4.png" class="centered"  >';
        }

      ?>
       
	    </div>
    </div>
</div>
</body>
<script type="text/javascript">
  function doPrint() {
    window.print();
    window.onafterprint = function(event) {
        window.location.href = 'index.php'
    };
}
</script>
</html>
