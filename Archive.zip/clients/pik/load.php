<?php 
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');
   
        $query = mysqli_query($management_connection, "SELECT * FROM Galery WHERE Phone = '$phone' AND DATE(Times) = CURDATE() ORDER BY ID DESC LIMIT 5");
        while ($row = mysqli_fetch_array($query)){
            $images[] =$row['Images'];
            
        }
         
        echo json_encode($images, JSON_FORCE_OBJECT);

    ?>