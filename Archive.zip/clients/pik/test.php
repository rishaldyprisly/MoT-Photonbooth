<?php
	echo 'sesuatu';
?>