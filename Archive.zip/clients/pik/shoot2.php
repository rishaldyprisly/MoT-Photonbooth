<?php
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');
$var1 = "";
$var2 = "";
$var3 = "";
$var4 = "";

?>
<!DOCTYPE html>
<!-- <html lang="en" class="no-js"> -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Switch Template</title>
    <!-- <link href="https://fonts.googleapis.com/css?family=Heebo:400,700|IBM+Plex+Sans:600" rel="stylesheet"> -->
    <link rel="stylesheet" href="dist/css/style.css">
    <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>
    <link href="https://fonts.cdnfonts.com/css/bank-gothic" rel="stylesheet">
    <link rel="stylesheet" href="dist/css/instagram.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <style type="text/css">
        font-family: 'Bank Gothic', sans-serif;

                                                
        .img-show {
          display: block;
          width:280;
          height:890px;
        }
        #savedImages{
            /*display: inline-flex;*/
            position: absolute;
            margin-top: 30px;
            margin-left: 15%;
            text-align: left;
            max-width: 280px;
            max-height: 950px;
            /*background-color: #fff;*/
            /*//border-radius: 5px;*/
        } 
        #savedImages h1, #savedImages h2, #savedImages h3{
            color: red;
            padding: 0 20px;
        }
            
        #savedImages img {
            margin: 5px;
        }
        
        
        .capsule{
        /*background: #fff;*/
        border-radius: 30px;
        -webkit-mask-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAA5JREFUeNpiYGBgAAgwAAAEAAGbA+oJAAAAAElFTkSuQmCC);
         }

        .container1 { 
          height: 200px;
          position: relative;
          border: 3px solid green; 
        }

        .center {
          margin: 0;
          position: absolute;
          top: 85%;
          left: 25%;
          -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
        }
        .centered {
          position: absolute;
          top: 20%;
          left: 25%;
          transform: translate(-50%, -50%);
        }
        
        .centered2 {
          position: absolute;
          top: 15%;
          left: 25%;
          transform: translate(-50%, -50%);
        }

        #canvas{
            display: none;
            position: absolute;
            top: 150px;
            left: 0px;

        }
        .bg-images {
          background-image: url('dist/images/astro-shoot.jpg');
        }
        .column {
          float: left;
          width: 49.4%;
          padding: 5px;
          height: 985px; /* Should be removed. Only for demonstration */
        }

        /* Clear floats after the columns */
        .row:after {
          content: "";
          display: table;
          clear: both;
        }

        .container::-webkit-scrollbar { 
            display: none;  /* Safari and Chrome */
        }

        .greens { 
            position: relative;
            margin-top: 65%;
            margin-left: 79.5%;
            text-align: left;
            max-width: 280px;
            max-height: 950px;
        }

        .moons { 
            position: relative;
            margin-top: -1600px;
            margin-left: 74%;
            text-align: left;
            max-width: 230px;
            max-height: 230px;
        }
        .moons-sm { 
            position: relative;
            margin-top: -1600px;
            margin-left: 60px;
            text-align: left;
            max-width: 100px;
            max-height: 100px;
        }
        
        .astro-md { 
            position: relative;
            margin-top: -710px;
            margin-left: -140px;
            text-align: left;
            max-width: 250px;
            max-height: 250px;
        }

        .max-md { 
            position: inherit;
            margin-top: -208px;
            margin-left: -335px;
            text-align: left;
            max-width: 550px;
            max-height: 250px;
        }
        .moons-md { 
            position: relative;
            margin-top: -540px;
            margin-left: -330px;
            text-align: left;
            max-width: 80px;
            max-height: 80px;
        }
        .frame-1 { 
            position: absolute;
            margin-top: 30px;
            margin-left: 15%;
            text-align: left;
            max-width: 450px;
            /*max-height: 250px;*/
        }


        .frame-2 { 
            position: absolute;
            margin-top: 30px;
            margin-left: 32%;
            text-align: right;
            max-width: 450px;
            /*max-height: 250px;*/
        }
        .frame-2b { 
            position: absolute;
            margin-top: 240px;
            margin-left: 32%;
            text-align: right;
            max-width: 450px;
            /*max-height: 250px;*/
        }

        .frame-2c { 
            position: absolute;
            margin-top: 450px;
            margin-left: 32%;
            text-align: right;
            max-width: 450px;
            /*max-height: 250px;*/
        }
        .frame-2d { 
            position: absolute;
            margin-top: 660px;
            margin-left: 32%;
            text-align: right;
            max-width: 450px;
            /*max-height: 250px;*/
        }

        .captured { 
            position: absolute;
            margin-top: 30px;
            margin-left: 15%;
            text-align: left;
            max-width: 450px;
            /*max-height: 250px;*/
        }
        .button4{
            margin-top: 890px;
            margin-left: 690px;
            position: absolute;
            background-color: #fc03c6; 
            border: none;
            color: #fff;
            padding: 10px 57px;
            text-align: center;
            cursor: pointer; 
        }
        
        
    </style>
</head>

<body class="is-boxed has-animations" onload="hide_print()">
    
    <audio id="shutterSound">
      <source src="resources/capture.mp3" type="audio/mpeg">
    </audio>
        <main>
             
            <div class="row">
                <div class="column" style="background-color:black;">
                    
                    <video autoplay id="video" class="capsule features-illustration" ></video>
                    <img src="dist/images/green.png" width="200px" class="greens">
                    <img src="dist/images/moon.png" width="230px" class="moons">
                    <img src="dist/images/moon.png" width="100px" class="moons-sm">
                    
                    <img src="dist/images/astro.png" width="250px" class="astro-md">
                    <img src="dist/images/max.png" width="550px" class="max-md">
                    <img src="dist/images/moon.png" width="150px" class="moons-md">
                </div>

                <div class="column" style="background-color:#fff;">
                    <canvas id="canvas" style="background-color: #fff;"></canvas>
                    <canvas id="myCanvas3" width="300" height="900" style="background-color:#bbb;" class="captured"></canvas>
                    <button class="button4" id="print_btn" onclick="prints();"> Print</button>
                    <!-- <div id="savedImages"  class="img-show"></div> -->
                    <img src="" width="300px" class="frame-1" id="loadFrame">
                    <img src="dist/images/selfie.jpeg" width="300px" class="frame-2  filter-perpetua" onclick="perpetua()">
                    <img src="dist/images/selfie.jpeg" width="300px" class="frame-2b filter-valencia" onclick="valencia()">
                    <img src="dist/images/selfie.jpeg" width="300px" class="frame-2c filter-inkwell" onclick="inkwell()">
                    <img src="dist/images/selfie.jpeg" width="300px" class="frame-2d filter-gingham" onclick="gingham()">

                    
                </div>
			</div>
    		<h2 id="timer" class="section-title mt-0 centered">5 s</h2>
			<h2 id="warming" class="section-title mt-0 centered2">Say Cheese 🧀</h2>
			<button id="buttonCapture" class="button button-primary center" width="250" >Capture</button>
            <button id="buttonSave" disabled hidden>Save</button>    
                
        </main>
    
    <script src="dist/js/main.min.js"></script>
    <script type="text/javascript">
        const shoot = localStorage.getItem('frame');
        var canvas3 = document.getElementById("myCanvas3");
        var filter  = 0;
        console.log(shoot);
        
        var frame   = document.getElementById("loadFrame");
        if (shoot   == "1"){
            var shots = 2;
            var ctx3 = canvas3.getContext('2d');
                            
            var img0 = new Image();
            img0.src = 'dist/images/frames-1.png';
            ctx3.drawImage(img0, 0, 0, 300, 900);

            frame.src= 'dist/images/frames-1.png';



        }
        if (shoot   == "2"){
            var shots = 2;
            var ctx3 = canvas3.getContext('2d');
                            
            var img0 = new Image();

            img0.src = 'dist/images/frames-2.png';
            ctx3.drawImage(img0, 0, 0,  300, 900);
            frame.src= 'dist/images/frames-2.png';
        }


        if (shoot   == "3"){
            var shots = 3;
            var ctx3 = canvas3.getContext('2d');
                            
            var img0 = new Image();
            img0.src = 'dist/images/frames-3.png';
            ctx3.drawImage(img0, 0, 0,  300, 900);
            frame.src= 'dist/images/frames-3.png';
        }

        if (shoot   == "4"){
            var shots = 4;
            var ctx3 = canvas3.getContext('2d');
                            
            var img0 = new Image();
            img0.src = 'dist/images/frames-4.png';
            ctx3.drawImage(img0, 0, 0,  300, 900);
            frame.src= 'dist/images/frames-4.png';
        }


        var buttonCapture = document.getElementById("buttonCapture");
        var buttonSave    = document.getElementById("buttonSave");
        var timerText     = document.getElementById("timer");
        var warmingText   = document.getElementById("warming");
        var savedImages   = document.getElementById("savedImages");
        var canvas        = document.getElementById("canvas");
        
        var video         = document.getElementById("video");
        var shutter       = document.getElementById("shutterSound"); 

        var ctx3 = canvas3.getContext('2d');
                            
       

        var context;
        var width = 720; 
        var height = 720;

        var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
        var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer, Inc/.test(navigator.vendor);

        video.width = width;
        video.height = height;

        var canvas = canvas;
        canvas.style.width = "300px";
        canvas.width = width;
        canvas.fillStyle = "#FF0000";

        context = canvas.getContext("2d");

        if((isChrome || isSafari) && window.location.protocol == "http:") {
            savedImages.innerHTML = "<h1>This browser only supports camera streams over https:</h1>";
        } else {
            startWebcam();
        }

        function startWebcam() {
            navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mediaDevices || navigator.mozGetUserMedia || navigator.msGetUserMedia || navigator.oGetUserMedia;

            if (navigator.mediaDevices){
                navigator.mediaDevices.getUserMedia({video: true}, handleVideo, videoError).then(function(stream){
                    video.onloadedmetadata = setHeight;
                    buttonCapture.disabled = false;
                    return video.srcObject = stream;
                }).catch(function(e) {
                    console.log(e.name + ": "+ e.message);
                    
                    buttonCapture.disabled = true;
                    
                    switch(e.name) {
                        case "NotAllowedError":
                            savedImages.innerHTML = "<h3>You can't use this app because you denied camera access. Refresh the page and allow the camera to be used by this app.</h3>";
                            break;
                        case "NotReadableError":
                            savedImages.innerHTML = "<h3>Camera not available. Your camera may be used by another application.</h3>";
                            break;
                        case "NotFoundError":
                            savedImages.innerHTML = "<h3>Camera not available. Please connect a camera to your device.</h3>";
                            break;
                    }
                });
            } else {
                savedImages.innerHTML = "<h3>Camera not supported.</h3>";
            }

            function handleVideo(stream) {
                video.src = window.URL.createObjectURL(stream);
            }

            function videoError(e) {
                savedImages.innerHTML = "<h3>" + e +"</h3>";
            }
            
            function setHeight() {
                var ratio = video.videoWidth / video.videoHeight;
                height = width/ratio;
                canvas.style.height = height + "px";
                canvas.height = height
            }
            function sleep(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
            }
            buttonSave.addEventListener("mousedown", handleButtonSaveClick);
            
            function handleButtonSaveClick() {
                if(canvas.style.display == "none" || canvas.style.display == ""){
                    canvas.style.display = "none"; //on capture show canvas

                    console.log("Canvas Display Block");
                    
                    setHeight();
                    context.drawImage(video, 0, 0, width, height);
                   
                
                    var dataURL = canvas.toDataURL("image/jpg");
                    var xhr = new XMLHttpRequest();
                    var form = new FormData();
                    form.append("image", dataURL);
                    
                    
                    xhr.open("POST", "save.php", true);
                    xhr.onreadystatechange = console.log("Status : " + xhr.readyState);
                
                    xhr.onprogress = () => {
                        console.log('LOADING', xhr.readyState); // readyState will be 3
                    };
                    
                    xhr.onload = function() {
                    if (xhr.readyState == 4 ) {
                        if(xhr.status == 200) {
                            var image = new Image();
                            image.src = "https://localhost/photobooth/clients/pik/images/" + xhr.responseText;
                            
                            buttonSave.innerHTML = "Saved";
                            buttonSave.disabled = true;
                            makeCaptureButton();

                            console.log('Done', xhr.readyState); // readyState will be 3


                            $.get('load.php', function(data) {
                            console.log(data);
                            var obj = $.parseJSON(data);


                            var canvas3 = document.getElementById("myCanvas3");
                            var ctx3 = canvas3.getContext('2d');
                            
                            var img1 = new Image();
                            img1.src = 'https://localhost/photobooth/clients/pik/images/'+obj['0'];
                            ctx3.drawImage(img1, 14, 7, 272, 202);

                            var img2 = new Image();
                            img2.src= 'https://localhost/photobooth/clients/pik/images/'+obj['1'];
                            ctx3.drawImage(img2, 14, 215,272,202);

                            var img3 = new Image();
                            img3.src= 'https://localhost/photobooth/clients/pik/images/'+obj['2'];
                            ctx3.drawImage(img3, 14, 410,272,202);

                            var img4 = new Image();
                            img4.src = 'https://localhost/photobooth/clients/pik/images/'+obj['3'];
                            ctx3.drawImage(img4, 14, 615,272,202);

                            });
                            
                        }
                    }
                };

                    xhr.send(form);
                    xhr.onreadystatechange = console.log("Status : " + xhr.readyState);
                    
            }
            }

          
            function handleButtonCaptureClick() {
                if(canvas.style.display == "none" || canvas.style.display == ""){
                    canvas.style.display = "none"; //on capture show canvas
                    console.log("Canvas Display Block");
                    
                    setHeight();
                    context.drawImage(video, 0, 0, width, height);
                    // buttonSave.innerHTML = "Save";
                    // buttonSave.disabled = false;
                    handleButtonSaveClick();

                    

                } else {
                    makeCaptureButton();

                }
            }
            
            function makeCaptureButton() {
                canvas.style.display = "none";
                buttonCapture.innerHTML = "Capture";

                buttonSave.innerHTML = "Save";
                buttonSave.disabled = true;
            }

            
            
            
            $("#buttonCapture").click(function(e) { 
                buttonCapture.style.display = "none";
                setInterval(cts, 3000);
                //cts();



            });

            var timer = null;
            var pictures = 0;

           
            function cts() {
               
                if (pictures < shots){
                    console.log("pictures : " + pictures);

                    if (timer !== null ) {
                    } else {
                            var timeto = 4; // time in seconds to capture
                            var countdown = $("#timer").html(timeto);
                            $("#autoshootmsg").show();
                            timer = window.setInterval(function() {
                                timerText.innerHTML = timeto--;
                                countdown.html(timeto);
                                if (timeto >= 1) {
                                    timerText.style.display = "block";
                                };
                                if (timeto <= 1) {
                                    timerText.style.display = "none";
                                     
                                };
                                
                                if (timeto == 0) {
                                    shutter.play(); 
                                    window.clearInterval(timer);
                                    timer = null;
                                    handleButtonSaveClick();
                                };
                        }, 1000);
                        pictures = pictures + 1;
                        console.log("pictures : " + pictures);
                        
                        
                    };
                
                hide_print();

                }
               

                if (pictures == shots){
                    
                    console.log( shots + "  Pictures captured, loop ended");
                    console.log()
                    $.get('load.php', function(data) {
                            console.log(data);
                            var obj = $.parseJSON(data);

                            if (shoot == 4){
                                var canvas3 = document.getElementById("myCanvas3");
                                var ctx3 = canvas3.getContext('2d');
                                
                                var img1 = new Image();
                                img1.src = 'https://localhost/photobooth/clients/pik/images/'+obj['0'];
                                ctx3.drawImage(img1, 14, 7, 272, 202);

                                var img2 = new Image();
                                img2.src= 'https://localhost/photobooth/clients/pik/images/'+obj['1'];
                                ctx3.drawImage(img2, 14, 215,272,202);

                                var img3 = new Image();
                                img3.src= 'https://localhost/photobooth/clients/pik/images/'+obj['2'];
                                ctx3.drawImage(img3, 14, 410,272,202);

                                var img4 = new Image();
                                img4.src = 'https://localhost/photobooth/clients/pik/images/'+obj['3'];
                                ctx3.drawImage(img4, 14, 615,272,202);

                                var img5 = new Image();
                                img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-4.png';
                                ctx3.drawImage(img5, 0, 0,300,900);

                             }


                             if (shoot == 3){
                                var canvas3 = document.getElementById("myCanvas3");
                                var ctx3 = canvas3.getContext('2d');
                                
                                var img1 = new Image();
                                img1.src = 'https://localhost/photobooth/clients/pik/images/'+obj['0'];
                                ctx3.drawImage(img1, 14, 7, 272, 202);

                                var img2 = new Image();
                                img2.src= 'https://localhost/photobooth/clients/pik/images/'+obj['1'];
                                ctx3.drawImage(img2, 14, 215,272,202);

                                var img3 = new Image();
                                img3.src= 'https://localhost/photobooth/clients/pik/images/'+obj['2'];
                                ctx3.drawImage(img3, 14, 410,272,202);

                                var img5 = new Image();
                                img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-3.png';
                                ctx3.drawImage(img5, 0, 0,300,900);

                             }

                             if (shoot == 2){
                                var canvas3 = document.getElementById("myCanvas3");
                                var ctx3 = canvas3.getContext('2d');
                                
                                var img1 = new Image();
                                img1.src = 'https://localhost/photobooth/clients/pik/images/'+obj['0'];
                                ctx3.drawImage(img1, 14, 7, 272, 400);

                                var img2 = new Image();
                                img2.src= 'https://localhost/photobooth/clients/pik/images/'+obj['1'];
                                ctx3.drawImage(img2, 14, 410,272,400);

                                var img5 = new Image();
                                img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-2.png';
                                ctx3.drawImage(img5, 0, 0,300,900);
                                
                             }

                             if (shoot == 1){
                                var canvas3 = document.getElementById("myCanvas3");
                                var ctx3 = canvas3.getContext('2d');
                                
                                var img1 = new Image();
                                img1.src = 'https://localhost/photobooth/clients/pik/images/'+obj['0'];
                                ctx3.drawImage(img1, 14, 7, 272, 400);

                                var img2 = new Image();
                                img2.src= 'https://localhost/photobooth/clients/pik/images/'+obj['1'];
                                ctx3.drawImage(img2, 14, 410,272,400);
                               

                                var img5 = new Image();
                                img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-1.png';
                                ctx3.drawImage(img5, 0, 0,300,900);


                             }
                            });
                         
                    //window.location = 'https://localhost/photobooth/clients/pik/layout.php'
                    
                }
                show_print();
            }
            
           }

           



        
    </script>

    <script type="text/javascript">

        function hide_print() {
                var prnt_btn = document.getElementById("print_btn");
                prnt_btn.style.display = "none";
            }

        function show_print() {
            var prnt_btn = document.getElementById("print_btn");
            prnt_btn.style.display = "block";
        }


        function prints() {
                var dataURL = canvas3.toDataURL("image/jpg");
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "save-layout.php");
                xhr.onload = function() {
                    if (xhr.readyState == 4 ) {
                        if(xhr.status == 200) {
                            console.log("XHR COMPLETED");
                                                  
                        }
                    }
                };
                var form = new FormData();
                form.append("image", dataURL);
                form.append("layout", shoot);
                form.append("filter", filter);
                xhr.send(form);
                
                window.location = 'print.php'
            }


        function gingham() {
           console.log("Filter - gingham")
           var element = document.getElementById("myCanvas3");
           element.classList.add("filter-gingham");
           element.classList.remove("filter-valencia");
           element.classList.remove("filter-inkwell");
           element.classList.remove("filter-perpetua");
           filter = 1;
           if (shoot   == "1"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-1.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "2"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-2.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "3"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-3.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "4"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-4.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
        }

        function inkwell() {
           console.log("Filter - inkwell")
           var element = document.getElementById("myCanvas3");
           element.classList.add("filter-inkwell");
           element.classList.remove("filter-valencia");
           element.classList.remove("filter-perpetua");
           element.classList.remove("filter-gingham");
           filter = 2;
           if (shoot   == "1"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-1.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "2"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-2.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "3"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-3.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "4"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-4.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
        }

        function valencia() {
           console.log("Filter - valencia")
           var element = document.getElementById("myCanvas3");
           element.classList.add("filter-valencia");
           element.classList.remove("filter-perpetua");
           element.classList.remove("filter-inkwell");
           element.classList.remove("filter-gingham");
           filter = 3;
           if (shoot   == "1"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-1.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "2"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-2.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "3"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-3.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "4"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-4.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
        }

        function perpetua() {
           console.log("Filter - perpetua")
           var element = document.getElementById("myCanvas3");
           element.classList.add("filter-perpetua");
           element.classList.remove("filter-valencia");
           element.classList.remove("filter-inkwell");
           element.classList.remove("filter-gingham");
           filter = 4;
           if (shoot   == "1"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-1.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "2"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-2.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "3"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-3.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
            if (shoot   == "4"){
               var img5 = new Image();
               img5.src = 'https://localhost/photobooth/clients/pik/dist/images/frames-4.png';
               ctx3.drawImage(img5, 0, 0,300,900);
            } 
        }


    </script>
</body>
</html>
