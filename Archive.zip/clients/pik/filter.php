<?php
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');
$query = mysqli_query($management_connection, "SELECT * FROM Layout WHERE Phone = '$phone' ORDER BY ID DESC LIMIT 1");
    while ($row = mysqli_fetch_assoc($query)) {
        $var = $row['Images'];
    }
 
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>MoT Photobooth</title>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
<link href="dist/css/style.css" rel="stylesheet"> 
<link rel="stylesheet" href="dist/css/instagram.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- <script defer src="script.js"></script> -->
<style>
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 16%;
  padding: 10px;
  /*height: 300px;  Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

button {
    display:block; 
    margin:0 auto;
    width: 335px; //or whatever
}
</style>


</head>

<body style="background-color: #f2f2f2;">

<div class="content">
	<div class="row">
        <div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>"  >
			    <form action="#" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="">
			        <input type="submit" name="submit" value="Print" class="button button-primary" >Print
			        
			    </form>
			</div>
		</div>
		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-mayfair" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-mayfair">
			        <input type="submit" name="submit" value="Print" class="button button-primary" >Print
			        
			    </form>
			</div>
		</div>

		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-sierra" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-sierra">
			        <input type="submit" name="submit" value="Print" class="button button-primary" >Print
			        
			    </form>
			</div>
		</div>

	    <div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-sutro" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-sutro">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>
		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-1977" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-1977">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>

		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-inkwell" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-inkwell">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>
	</div>
	
	<div class="row">
        <div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-perpetua" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-perpetua">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>
		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-valencia" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-valencia">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>

		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-crema" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-crema">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>

	    <div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-reyes" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-reyes">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>
		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-walden" >
			    <form action="" methode="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-walden">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>

		<div class="column" style="column-width:200px;" >
			<div class="holder" style="background: #ffffff;" >
			    <img src="<?php echo $var;?>" class="filter-moon" >
			    <form action="#" method="POST">
			        <input type="hidden" name="image"  value="<?php echo $var;?>">
			        <input type="hidden" name="filter" value="filter-moon">
			        <button type="submit" name="submit" value="Print" class="button button-primary" >Print</button>
			        
			    </form>
			</div>
		</div>
	</div>
</div>
</body>
<?php 
    if(isset($_POST['image'])){
      $phone = $_SESSION['Phone'];
      $image  = $_POST['image']; 
      $filter = $_POST['filter']; 
      $times  = date("l Y-m-d H:i:s");
      $query  = mysqli_query($management_connection, "INSERT INTO Printed (Booth, Phone, Images, Filter) 
                                                            VALUES ('PIK - COVE', '$phone', '$image', '$filter') ");
      if ($query){

          echo  "<script>window.location = 'https://localhost/photobooth/clients/pik/print.php'</script>";
      }
      else {
          echo "<script>alert('Fail to store images')</script>";
      }
    }    
?>

</html>
