<?php 
session_start();
$phone = $_SESSION['Phone'];
include('../../config/config.php');

if ( isset($_POST["image"]) && !empty($_POST["image"]) ) { 
	$data     = $_POST["image"];
	$uri      =  substr($data,strpos($data,","));
	$folder   = "images";
	$file     =  $phone ."-". md5(uniqid()) . ".jpg";
	$location = $file;
	
	
	file_put_contents($folder . "/" . $file, base64_decode($uri));

	$query = mysqli_query($management_connection, "INSERT INTO Galery (Booth, Phone, Images) VALUES ('PIK - Cove', '$phone', '$location' )");
	
	echo $file;
}
?>