<?php
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
require '../../config/config.php';
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="https://fonts.googleapis.com/css?family=Heebo:400,700|IBM+Plex+Sans:600" rel="stylesheet">
    <link rel="stylesheet" href="dist/css/style.css">
    <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style type="text/css">
        .center {
          display: block;
          margin-left: auto;
          margin-right: auto;
         
          width: 50%;
        }

        .bg-images {
          background-image: url('dist/images/astro-background.png');
        }
        .payment-images {
          background-image: url('dist/images/astro-qr.jpg');
        }
        
    </style>
   
</head>
<body class="is-boxed has-animations">
    <div class="body-wrap boxed-container">
        <!-- <header class="site-header">
            <div class="container">
                <div class="site-header-inner">
                    <div class="brand header-brand">
                        <h1 class="m-0">
                            <a href="#">
								<img class="header-logo-image asset-light" src="dist/images/logo-light.svg" alt="Logo">
								<img class="header-logo-image asset-dark" src="dist/images/logo-dark.svg" alt="Logo">
                            </a>
                        </h1>
                    </div>
                </div>
            </div>
        </header> -->

        
        <br>
        <main>
            <section class="hero  bg-images">
                <div class=" ">
                    <div class="">
						<div class="hero-copy">
                            

	                        <!-- <h1 class="hero-title mt-0">Welcome 🍻!</h1> -->
	                        <!-- <p class="hero-paragraph">MoT text content .</p> -->
	                        <div class="hero-cta">

								<form action="" method="post" >
								<div class="lights-toggle">
                                    <input  type="text" name="Phones" class="button" checked="checked"  placeholder="0812345678" class="center" style="margin-left: 9.5em; margin-top: 15em;">
                                     <br><br>
									<input type="submit" name="submit" class="button button-primary" value="Continue 🏃🏼‍♀️🏃‍♂️" class="center" style="margin-left: 11.5em;">
								</div>
                           
                                
                                 </form>
							</div>
							
						</div>
						<div class="hero-media">
							
							<div class="hero-media-illustration">
								<!-- <img class="hero-media-illustration-image asset-light center" src="dist/images/pinkd1.png" alt="Hero media illustration">
                                <img class="hero-media-illustration-image asset-light center" src="dist/images/pinkb1.png" alt="Hero media illustration"> -->
                                <br>
                                <br>
                                <br>

								
							</div>
							<div class="hero-media-container">
								<!-- <img class="hero-media-image asset-light" src="dist/images/samples.jpeg" width="500" height="600" alt="Hero media"> -->
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
								
							</div>
						</div>
                    </div>
                </div>
            </section>
            <br>
                               
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
            <?php 
                if(isset($_POST['Phones'])){
                    
                  $phones = $_POST['Phones']; 
                  $times = date("l Y-m-d H:i:s");
                  $query = mysqli_query($management_connection, "INSERT INTO Transaction (Booth, Phone, Amount, TransactionTime, TransactionStatus) 
                                                                        VALUES ('PIK - COVE', '$phones', '50000', '$times', 'Waiting For Payment') ");
                  if ($query){
                      $_SESSION['Phone'] = $_POST['Phones'];
                      // echo  "<script>window.location = '#payment'</script>";
                       echo  "<script>window.location = 'frames.html'</script>";

                  }
                  else {
                      echo "<script>alert('Wrong Password, Please check your credentials!')</script>";
                  }
                }    
                ?>

            <section class="features section payment-images" id="payment">
                <div class="container">
					<div class="features-inner section-inner has-bottom-divider">
						<div class="features-header text-center">
							<div class="container-sm" id="payment">
								<!-- <h2 class="section-title mt-0">Pay with QRIS</h2>
	                            <p class="section-paragraph">Payment content.</p> -->
								<div class="features-image">

	
									
									<!-- <img class="center" src="dist/images/qris.png" alt="Feature box" width="300" height="350"> -->
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
								</div>
							</div>
                        </div>
                        
                    </div>
                </div>
            </section>

			<section class="cta section">
                <div class="container-sm">
                    <div class="cta-inner section-inner">
                        <div class="cta-header text-center">
                            <h2 class="section-title mt-0">Check Payment Status</h2>
                            <p class="section-paragraph">Saya sudah bayar - Content.</p>
							<div class="cta-cta">
								<a class="button button-primary" href="#">Check</a>
							</div>
					    </div>
                    </div>
                </div>
            </section>
        </main>

        
    </div>

    <script src="dist/js/main.min.js"></script>
</body>
</html>
