<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname =  "mot";

$management_connection = new mysqli($servername, $username, $password, $dbname);

if ($management_connection->connect_error) {
    die("Connection failed: " . $management_connection->connect_error);
    echo "ERROR";
}


?>